#pragma once
#include "sdk.h"
#include <thread>
#include <unordered_map>
#include "D3DX/d3dx9math.h"
#include <string>
#include "ida.hpp"

#define PI 3.14159265358979323846f

int screenWidth = GetSystemMetrics(SM_CXSCREEN);
int screenHeight = GetSystemMetrics(SM_CYSCREEN);




namespace Features
{
	inline bool LevelActorCaching;
	inline bool rUsername;
	inline bool rSnapline;
	inline bool rRenderCount;
	inline bool rFullbox;
	inline bool rRank;
	inline bool rSkeleton;
	inline bool rWeapon;
	inline int rFovSize = 200;
	inline bool rAimbot;
	inline bool rPrediction;
	inline bool rTriggerbot;
	inline int rSmooth = 5;
	inline int rAimkey = VK_RBUTTON;
	inline int rAimkey2 = VK_RBUTTON;
	inline int rTrigkey = VK_RBUTTON;
	inline bool rFovCircle;
	inline bool rDistance;
	inline bool gaybox;
	inline bool distance;
	inline bool target_line;
	inline bool ignoredowned;
	inline bool fps = 1;
	inline bool corneredbox;
	inline bool noreload;
	inline bool levels;
	inline bool magicbullet;
	inline bool rgbskeleton;
	inline bool silentaim;
	inline bool FOVchanger;
	inline bool rMemory;


	inline int g_box_thick = 2;
}

namespace Offsets {
	uint64_t
		UWorld = 0x11ECD148,
		GNames = 0x120A7A40,
		GameState = 0x160,
		PlayerArray = 0x2A8,
		GameInstance = 0x1D8,
		LocalPlayers = 0x38,
		PlayerController = 0x30,
		LocalPawn = 0x338,
		PlayerState = 0x2B0,
		RootComponent = 0x198,
		PersistentLevel = 0x30,
		AActors = 0xA0,
		ActorCount = 0xA8,
		ReviveFromDBNOTime = 0x4C30,
		Mesh = 0x310,
		TeamIndex = 0x11d1,
		Platform = 0x438,
		PawnPrivate = 0x308,
		RelativeLocation = 0x120,
		PrimaryPickupItemEntry = 0x350,
		ItemDefinition = 0x18,
		Rarity = 0x9A,
		ItemName = 0x40,
		Levels = 0x178,
		WeaponData = 0x510,
		AmmoCount = 0xEEC,
		bIsTargeting = 0x581,
		ComponentVelocity = 0x168,
		TargetedFortPawn = 0x18C8,
		CurrentWeapon = 0xA68,
		BoneArray = 0x570,
		BoneCache = 0x600,
		LastSubmitTime = 0x2E8,
		LastRenderTime = 0x2E0,
		ComponentToWorld = 0x1c0,
		GlobalAnimRateScale = 0xA18,
		bIsReloadingWeapon = 0x388,
		OnSetFirstPersonCamera = 0x1098,
		AcknowledgedPawn = 0x338,
		bAllowTargeting = 0xe58;
}

#define FortPTR uintptr_t

#define CURRENT_CLASS reinterpret_cast<uintptr_t>(this)
#define DECLARE_MEMBER(type, name, offset) type name() { return read<type>(CURRENT_CLASS + offset); }
#define DECLARE_MEMBER_DIRECT(type, name, base, offset) type name() { read<type>(base + offset); }
#define DECLARE_MEMBER_BITFIELD(type, name, offset, index) type name() { read<type>(CURRENT_CLASS + offset) & (1 << index); }
#define APPLY_MEMBER(type, name, offset) void name( type val ) { write<type>(CURRENT_CLASS + offset, val); }
#define APPLY_MEMBER_BITFIELD(type, name, offset, index) void name( type val ) { write(CURRENT_CLASS + offset, |= val << index); }

DWORD_PTR Uworld_Cam;

class UObject {
public:
	FortPTR GetAddress()
	{
		return (FortPTR)this;
	}

	DECLARE_MEMBER(int, GetObjectID, 0x18);

	__forceinline operator uintptr_t() { return (FortPTR)this; }
};

class USceneComponent : public UObject
{
public:
	DECLARE_MEMBER(Vector3, RelativeLocation, Offsets::RelativeLocation);
	DECLARE_MEMBER(FBoxSphereBounds, Bounds, Offsets::RelativeLocation - 0x38);
	DECLARE_MEMBER(Vector3, GetComponentVelocity, Offsets::ComponentVelocity);
	APPLY_MEMBER(Vector3, K2_SetActorLocation, Offsets::RelativeLocation);
};

class AActor : public UObject {
public:
	DECLARE_MEMBER(USceneComponent*, RootComponent, Offsets::RootComponent);

	Vector3 K2_GetActorLocation_AlwaysCached() {
		static std::unordered_map<int, Vector3> CachedLocations;
		auto it = CachedLocations.find((int)this->GetAddress());
		if (it != CachedLocations.end()) {
			return it->second;
		}

		Vector3 ReturnValue = this->RootComponent()->RelativeLocation();

		CachedLocations[(int)this->GetAddress()] = ReturnValue;

		return ReturnValue;
	}

	Vector3 K2_GetActorLocation_Cached() {
		static std::unordered_map<int, Vector3> CachedLocations;
		if (Features::LevelActorCaching)
		{
			auto it = CachedLocations.find((int)this->GetAddress());
			if (it != CachedLocations.end()) {
				return it->second;
			}
		}

		Vector3 ReturnValue = this->RootComponent()->RelativeLocation();

		CachedLocations[(int)this->GetAddress()] = ReturnValue;

		return ReturnValue;
	}
};








class USkeletalMeshComponent : public AActor {
public:
	__forceinline Vector3 GetSocketLocation(int bone_id)
	{
		int IsCached = read<int>((FortPTR)this + Offsets::BoneCache);
		auto BoneTransform = read<FTransform>(read<uintptr_t>((FortPTR)this + 0x10 * IsCached + 0x570) + 0x60 * bone_id);

		FTransform ComponentToWorld = read<FTransform>((FortPTR)this + 0x1c0);

		D3DMATRIX Matrix;
		Matrix = MatrixMultiplication(BoneTransform.ToMatrixWithScale(), ComponentToWorld.ToMatrixWithScale());
		return Vector3(Matrix._41, Matrix._42, Matrix._43);
	}
	//
	__forceinline bool WasRecentlyRendered(float tolerence)
	{
		float LastSubmitTime = read<float>(this->GetAddress() + Offsets::LastSubmitTime);
		float LastRenderTimeOnScreen = read<float>(this->GetAddress() + Offsets::LastRenderTime);

		return LastRenderTimeOnScreen + tolerence >= LastSubmitTime;
	}

	auto is_shootable(Vector3 lur, Vector3 bone) -> bool {

		if (lur.x >= bone.x - 20 && lur.x <= bone.x + 20 && lur.y >= bone.y - 20 && lur.y <= bone.y + 20 && lur.z >= bone.z - 30 && lur.z <= bone.z + 30) return true;
		else return false;

	}
};

inline std::wstring MBytesToWString(const char* lpcszString)
{

	int len = strlen(lpcszString);
	int unicodeLen = ::MultiByteToWideChar(CP_ACP, 0, lpcszString, -1, NULL, 0);
	wchar_t* pUnicode = new wchar_t[unicodeLen + 1];
	memset(pUnicode, 0, (unicodeLen + 1) * sizeof(wchar_t));
	::MultiByteToWideChar(CP_ACP, 0, lpcszString, -1, (LPWSTR)pUnicode, unicodeLen);
	std::wstring wString = (wchar_t*)pUnicode;
	delete[] pUnicode;
	return wString;
}
inline std::string WStringToUTF8(const wchar_t* lpwcszWString)
{

	char* pElementText;
	int iTextLen = ::WideCharToMultiByte(CP_UTF8, 0, (LPWSTR)lpwcszWString, -1, NULL, 0, NULL, NULL);
	pElementText = new char[iTextLen + 1];
	memset((void*)pElementText, 0, (iTextLen + 1) * sizeof(char));
	::WideCharToMultiByte(CP_UTF8, 0, (LPWSTR)lpwcszWString, -1, pElementText, iTextLen, NULL, NULL);
	std::string strReturn(pElementText);
	delete[] pElementText;
	return strReturn;
}



inline void DrawString(float fontSize, int x, int y, ImColor color, bool bCenter, bool stroke, const char* pText, ...)
{
	ImDrawList* drawList = ImGui::GetOverlayDrawList();
	va_list va_alist;
	char buf[128] = { 0 };
	va_start(va_alist, pText);
	_vsnprintf_s(buf, sizeof(buf), pText, va_alist);
	va_end(va_alist);
	std::string text = WStringToUTF8(MBytesToWString(buf).c_str());
	if (bCenter)
	{
		ImVec2 textSize = ImGui::CalcTextSize(text.c_str());
		x = x - textSize.x / 4;
		y = y - textSize.y;
	}
	if (stroke)
	{
		drawList->AddText(ImGui::GetFont(), fontSize, ImVec2(x + 1, y + 1), ImGui::ColorConvertFloat4ToU32(ImVec4(0, 0, 0, 1)), text.c_str());
		drawList->AddText(ImGui::GetFont(), fontSize, ImVec2(x - 1, y - 1), ImGui::ColorConvertFloat4ToU32(ImVec4(0, 0, 0, 1)), text.c_str());
		drawList->AddText(ImGui::GetFont(), fontSize, ImVec2(x + 1, y - 1), ImGui::ColorConvertFloat4ToU32(ImVec4(0, 0, 0, 1)), text.c_str());
		drawList->AddText(ImGui::GetFont(), fontSize, ImVec2(x - 1, y + 1), ImGui::ColorConvertFloat4ToU32(ImVec4(0, 0, 0, 1)), text.c_str());
	}
	drawList->AddText(ImGui::GetFont(), fontSize, ImVec2(x, y), ImColor(color), text.c_str());
}


struct CameraInfo
{
	Vector3 location;
	Vector3 rotation;
	float fov;
};

CameraInfo Copy_CameraInfo;

FortPTR Copy_PlayerController_Camera;

CameraInfo camera;

CameraInfo GetCameraInfo()
{
	if (Copy_PlayerController_Camera)
	{
		auto location_pointer = read<uintptr_t>(Uworld_Cam + 0x110); //110
		auto rotation_pointer = read<uintptr_t>(Uworld_Cam + 0x120); //120

		struct RotationInfo
		{
			double pitch;
			char pad_0008[24];
			double yaw;
			char pad_0028[424];
			double roll;
		};
		RotationInfo RotInfo;

		RotInfo = read<RotationInfo>(rotation_pointer);

		camera.location = read<Vector3>(location_pointer);
		camera.rotation.x = asin(RotInfo.roll) * (180.0 / PI);
		camera.rotation.y = ((atan2(RotInfo.pitch * -1, RotInfo.yaw) * (180.0 / PI)) * -1) * -1;
		camera.fov = read<float>(Copy_PlayerController_Camera + 0x394) * 90.f;

		return { camera.location, camera.rotation, camera.fov };
	}

	std::this_thread::sleep_for(std::chrono::milliseconds(1));
}

class ULevel : public UObject
{
public:
	DECLARE_MEMBER(DWORD, ActorCount, Offsets::ActorCount);
	DECLARE_MEMBER(FortPTR, AActors, Offsets::AActors);
};

class AFortPlayerState : public AActor
{
public:
	DECLARE_MEMBER(int, TeamIndex, Offsets::TeamIndex);
	DECLARE_MEMBER(AActor*, PawnPrivate, Offsets::PawnPrivate);
	DECLARE_MEMBER(DWORD_PTR, Platform, Offsets::Platform);
	std::string GetPlayerName()
	{
		int pNameLength;
		_WORD* pNameBufferPointer;
		int i;
		char v25;
		int v26;
		int v29;

		char16_t* pNameBuffer;

		uintptr_t pNameStructure = read<uintptr_t>((FortPTR)this + 0xab0);
		if (is_valid(pNameStructure)) {
			pNameLength = read<int>(pNameStructure + 0x10);
			if (pNameLength <= 0)
				return "BOT";

			pNameBuffer = new char16_t[pNameLength];
			uintptr_t pNameEncryptedBuffer = read<uintptr_t>(pNameStructure + 0x8);
			if (is_valid(pNameEncryptedBuffer)) {
				mem::read_physical((uintptr_t*)pNameEncryptedBuffer, (uint8_t*)(pNameBuffer), (pNameLength * 2));

				v25 = pNameLength - 1;
				v26 = 0;
				pNameBufferPointer = (_WORD*)pNameBuffer;

				for (i = (v25) & 3;; *pNameBufferPointer++ += i & 7) {
					v29 = pNameLength - 1;
					if (!(_DWORD)pNameLength)
						v29 = 0;

					if (v26 >= v29)
						break;

					i += 3;
					++v26;
				}

				std::u16string temp_wstring(pNameBuffer);
				delete[] pNameBuffer;
				return std::string(temp_wstring.begin(), temp_wstring.end());
			}
		}
	}
};

class UFortItemDefinition : public AActor
{
public:
	DECLARE_MEMBER(EFortRarity, Rarity, Offsets::Rarity);
	DECLARE_MEMBER(int, RarityInt, Offsets::Rarity);
	std::string ItemName()
	{
		std::string PlayersWeaponName = "";
		uint64_t ItemName = read<uint64_t>((FortPTR)this + Offsets::ItemName);
		if (!ItemName) return "";

		uint64_t FData = read<uint64_t>(ItemName + 0x28);
		int FLength = read<int>(ItemName + 0x30);

		if (FLength > 0 && FLength < 50) {

			wchar_t* WeaponBuffer = new wchar_t[FLength];
			mem::read_physical((PVOID)FData, (PVOID)WeaponBuffer, FLength * sizeof(wchar_t));
			std::wstring wstr_buf(WeaponBuffer);
			PlayersWeaponName.append(std::string(wstr_buf.begin(), wstr_buf.end()));

			delete[] WeaponBuffer;
		}
		return PlayersWeaponName;
	}
};

class AFortWeapon : public AActor
{
public:
	std::string GetWeaponName(uintptr_t Player) {
		std::string PlayersWeaponName = "";
		uint64_t CurrentWeapon = read<uint64_t>((FortPTR)Player + Offsets::CurrentWeapon);
		uint64_t weapondata = read<uint64_t>(CurrentWeapon + Offsets::WeaponData);
		uint64_t AmmoCount = read<uint64_t>(CurrentWeapon + Offsets::AmmoCount);
		uint64_t ItemName = read<uint64_t>(weapondata + Offsets::ItemName);
		if (!ItemName) return "";

		uint64_t FData = read<uint64_t>(ItemName + 0x28);
		int FLength = read<int>(ItemName + 0x30);

		if (FLength > 0 && FLength < 50) {

			wchar_t* WeaponBuffer = new wchar_t[FLength];
			mem::read_physical((void*)FData, (PVOID)WeaponBuffer, FLength * sizeof(wchar_t));
			std::wstring wstr_buf(WeaponBuffer);
			if (AmmoCount != 0) PlayersWeaponName.append(std::string(wstr_buf.begin(), wstr_buf.end()) + "[" + std::to_string(AmmoCount) + "]");
			else PlayersWeaponName.append(std::string(wstr_buf.begin(), wstr_buf.end()));

			delete[] WeaponBuffer;
		}
		return PlayersWeaponName;
	}

	float GetProjectileSpeed()
	{
		return read<float>(CURRENT_CLASS + 0x1CE0);
	}

	float GetGravityScale()
	{
		return read<float>(CURRENT_CLASS + 0x1CE4);
	}

	DECLARE_MEMBER(UFortItemDefinition*, WeaponData, Offsets::WeaponData);
	DECLARE_MEMBER(int, AmmoCount, Offsets::AmmoCount);
	DECLARE_MEMBER(bool, IsTargeting, Offsets::bIsTargeting);
};

class AFortPlayerPawn : public AActor
{
public:
	DECLARE_MEMBER(float, ReviveFromDBNOTime, Offsets::ReviveFromDBNOTime);
	DECLARE_MEMBER(AFortPlayerState*, PlayerState, Offsets::PlayerState);
	DECLARE_MEMBER(USkeletalMeshComponent*, Mesh, Offsets::Mesh);
	DECLARE_MEMBER(AFortWeapon*, CurrentWeapon, Offsets::CurrentWeapon);
};

class APlayerController : public AActor
{
public:
	D3DMATRIX Matrix(Vector3 rot, Vector3 origin = Vector3(0.f, 0.f, 0.f)) {
		float radPitch = (rot.x * float(PI) / 180.f);
		float radYaw = (rot.y * float(PI) / 180.f);
		float radRoll = (rot.z * float(PI) / 180.f);

		float SP = sinf(radPitch);
		float CP = cosf(radPitch);
		float SY = sinf(radYaw);
		float CY = cosf(radYaw);
		float SR = sinf(radRoll);
		float CR = cosf(radRoll);

		D3DMATRIX matrix;
		matrix.m[0][0] = CP * CY;
		matrix.m[0][1] = CP * SY;
		matrix.m[0][2] = SP;
		matrix.m[0][3] = 0.f;

		matrix.m[1][0] = SR * SP * CY - CR * SY;
		matrix.m[1][1] = SR * SP * SY + CR * CY;
		matrix.m[1][2] = -SR * CP;
		matrix.m[1][3] = 0.f;

		matrix.m[2][0] = -(CR * SP * CY + SR * SY);
		matrix.m[2][1] = CY * SR - CR * SP * SY;
		matrix.m[2][2] = CR * CP;
		matrix.m[2][3] = 0.f;

		matrix.m[3][0] = origin.x;
		matrix.m[3][1] = origin.y;
		matrix.m[3][2] = origin.z;
		matrix.m[3][3] = 1.f;

		return matrix;
	}

	Vector2 ProjectWorldLocationToScreen(Vector3 WorldLocation)
	{
		CameraInfo viewInfo = GetCameraInfo();
		D3DMATRIX tempMatrix = Matrix(viewInfo.rotation);
		Vector3 vAxisX = Vector3(tempMatrix.m[0][0], tempMatrix.m[0][1], tempMatrix.m[0][2]);
		Vector3 vAxisY = Vector3(tempMatrix.m[1][0], tempMatrix.m[1][1], tempMatrix.m[1][2]);
		Vector3 vAxisZ = Vector3(tempMatrix.m[2][0], tempMatrix.m[2][1], tempMatrix.m[2][2]);

		Vector3 vDelta = WorldLocation - viewInfo.location;
		Vector3 vTransformed = Vector3(vDelta.Dot(vAxisY), vDelta.Dot(vAxisZ), vDelta.Dot(vAxisX));

		if (vTransformed.z < 1.f)
			vTransformed.z = 1.f;

		return Vector2((screenWidth / 2.0f) + vTransformed.x * (((screenWidth / 2.0f) / tanf(viewInfo.fov * (float)PI / 360.f))) / vTransformed.z, (screenHeight / 2.0f) - vTransformed.y * (((screenWidth / 2.0f) / tanf(viewInfo.fov * (float)PI / 360.f))) / vTransformed.z);
	}

	DECLARE_MEMBER(FortPTR, AcknowledgedPawn, Offsets::LocalPawn);
	DECLARE_MEMBER(AFortPlayerPawn*, TargetedFortPawn, Offsets::TargetedFortPawn);
};

class ULocalPlayer : public AFortPlayerPawn
{
public:
	DECLARE_MEMBER(APlayerController*, PlayerController, Offsets::PlayerController);
};

class UGameInstance : public AActor
{
public:
	DECLARE_MEMBER(DWORD_PTR, LocalPlayers, Offsets::LocalPlayers);
};

class AGameStateBase : public UObject
{
public:
	DECLARE_MEMBER(TArray, PlayerArray, Offsets::PlayerArray);
};

class UWorld : public AActor
{
public:
	DECLARE_MEMBER(UGameInstance*, OwningGameInstance, Offsets::GameInstance);
	DECLARE_MEMBER(ULevel*, PersistentLevel, Offsets::PersistentLevel);
	DECLARE_MEMBER(AGameStateBase*, GameState, Offsets::GameState);
};

class FFortItemEntry : public AActor
{
public:
};

class AFortPickup : public AActor
{
public:
	DECLARE_MEMBER(UFortItemDefinition*, ItemDefinition, Offsets::PrimaryPickupItemEntry + Offsets::ItemDefinition);
};

namespace Cached
{
	APlayerController* PlayerController;
	AFortPlayerState* PlayerState;
	AFortPlayerState* LocalPlayerState;
	AFortPlayerPawn* LocalPawn;
	USceneComponent* LocalRootComponent;
	ULocalPlayer* LocalPlayer;
	ULevel* PersistentLevel;
	UWorld* World;
	AGameStateBase* GameState;
	AFortWeapon* CurrentWeapon;
	USkeletalMeshComponent* Mesh;


	inline AFortPlayerPawn* TargetEntity = 0;
	inline float ClosestDistance = FLT_MAX;


	Vector3 localactorpos;
}

double GetCrossDistance(double x1, double y1, double x2, double y2) {
	return sqrt(pow((x2 - x1), 2) + pow((y2 - y1), 2));
}