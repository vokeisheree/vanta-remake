#pragma once
#include "sdk.h"

void FullBox(int X, int Y, int W, int H, const ImColor color, int thickness);