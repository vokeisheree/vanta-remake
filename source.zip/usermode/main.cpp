﻿#include <windows.h>
#include <iostream>
#include <d3d9.h>
#include "ImGui/imgui.h"
#include "ImGui/imgui_impl_dx9.h"
#include "ImGui/imgui_impl_win32.h"
#include "driver.h"
#include <Uxtheme.h>
#include <dwmapi.h>
#include "winternl.h"
#include "Classes.h"
#include "SkCrypt.h"
#include "XORS.h"
#pragma comment(lib, "d3d9.lib")
#pragma comment(lib, "dwmapi.lib")

using namespace std;





uintptr_t dynamic_uworld;
uintptr_t va_text = 0;

IDirect3D9Ex* p_Object = NULL;
IDirect3DDevice9Ex* p_Device = NULL; //
D3DPRESENT_PARAMETERS p_Params = { NULL };

HWND GameHwnd = NULL;
HWND MyHwnd = NULL;
MSG Message = { NULL };

uintptr_t procid = NULL;

#define PI 3.14159265358979323846f
















const char* targetOptions[] = { "Head", "Neck", "Chest" };
static int currentTarget = 0;

static const char* keyNames[] =
{
    (""),
    ("Left Mouse"),
    ("Right Mouse"),
    ("Cancel"),
    ("Middle Mouse"),
    ("Mouse 5"),
    ("Mouse 4"),
    (""),
    ("Backspace"),
    ("Tab"),
    (""),
    (""),
    ("Clear"),
    ("Enter"),
    (""),
    (""),
    ("Shift"),
    ("Control"),
    ("Alt"),
    ("Pause"),
    ("Caps"),
    (""),
    (""),
    (""),
    (""),
    (""),
    (""),
    ("Escape"),
    (""),
    (""),
    (""),
    (""),
    ("Space"),
    ("Page Up"),
    ("Page Down"),
    ("End"),
    ("Home"),
    ("Left"),
    ("Up"),
    ("Right"),
    ("Down"),
    (""),
    (""),
    (""),
    ("Print"),
    ("Insert"),
    ("Delete"),
    (""),
    ("0"),
    ("1"),
    ("2"),
    ("3"),
    ("4"),
    ("5"),
    ("6"),
    ("7"),
    ("8"),
    ("9"),
    (""),
    (""),
    (""),
    (""),
    (""),
    (""),
    (""),
    ("A"),
    ("B"),
    ("C"),
    ("D"),
    ("E"),
    ("F"),
    ("G"),
    ("H"),
    ("I"),
    ("J"),
    ("K"),
    ("L"),
    ("M"),
    ("N"),
    ("O"),
    ("P"),
    ("Q"),
    ("R"),
    ("S"),
    ("T"),
    ("U"),
    ("V"),
    ("W"),
    ("X"),
    ("Y"),
    ("Z"),
    (""),
    (""),
    (""),
    (""),
    (""),
    ("Numpad 0"),
    ("Numpad 1"),
    ("Numpad 2"),
    ("Numpad 3"),
    ("Numpad 4"),
    ("Numpad 5"),
    ("Numpad 6"),
    ("Numpad 7"),
    ("Numpad 8"),
    ("Numpad 9"),
    ("Multiply"),
    ("Add"),
    (""),
    ("Subtract"),
    ("Decimal"),
    ("Divide"),
    ("F1"),
    ("F2"),
    ("F3"),
    ("F4"),
    ("F5"),
    ("F6"),
    ("F7"),
    ("F8"),
    ("F9"),
    ("F10"),
    ("F11"),
    ("F12")
};


HWND windowid = 0;

HWND(*_FindWindowA)(LPCSTR lpClassName, LPCSTR lpWindowName) = nullptr;

HWND __stdcall FindWindowA_Spoofed(LPCSTR lpClassName, LPCSTR lpWindowName) {

    return _FindWindowA(lpClassName, lpWindowName);
}




static bool Items_ArrayGetter(void* data, int idx, const char** out_text)
{
    const char* const* items = (const char* const*)data;
    if (out_text)
        *out_text = items[idx];
    return true;
}

static int keystatus = 0;

void ChangeKey(void* blank)
{
    keystatus = 1;
    while (true)
    {
        for (int i = 0; i < 0x87; i++)
        {
            if (GetKeyState(i) & 0x8000)
            {
                Features::rAimkey = i;
                keystatus = 0;
                return;
            }
        }
    }
}


static int trigkeystatus = 0;

void TrigChangeKey(void* blank)
{
    trigkeystatus = 1;
    while (true)
    {
        for (int i = 0; i < 0x87; i++)
        {
            if (GetKeyState(i) & 0x8000)
            {
                Features::rTrigkey = i;
                trigkeystatus = 0;
                return;
            }
        }
    }
}

void HotkeyButton(int aimkey, void* changekey, int status)
{
    const char* preview_value = NULL;
    if (aimkey >= 0 && aimkey < IM_ARRAYSIZE(keyNames))
        Items_ArrayGetter(keyNames, aimkey, &preview_value);

    string aimkeys;
    if (preview_value == NULL)
        aimkeys = ("Select Key");
    else
        aimkeys = preview_value;

    if (status == 1)
    {
        aimkeys = ("Press Key");
    }
    if (ImGui::Button(aimkeys.c_str(), ImVec2(125, 25)))
    {
        if (status == 0)
        {
            CreateThread(0, 0, (LPTHREAD_START_ROUTINE)changekey, nullptr, 0, nullptr);
        }
    }
}

void lgbt(const ImVec2& position, float radius)
{
    ImDrawList* draw_list = ImGui::GetOverlayDrawList();
    int num_segments = 64; // Number of segments to divide the circle
    for (int i = 0; i < num_segments; i++)
    {
        // Calculate angle for each segment
        float start_angle = (float)i / num_segments * 2.0f * PI;
        float end_angle = (float)(i + 1) / num_segments * 2.0f * PI;

        // Generate rainbow colors based on the segment index
        float hue = (float)i / num_segments;
        ImU32 color = ImGui::ColorConvertFloat4ToU32(ImColor::HSV(hue, 1.0f, 1.0f));

        // Draw each segment
        draw_list->PathArcTo(position, radius, start_angle, end_angle, 2);
        draw_list->PathStroke(color, false, 1.0f);
    }
}




void JunkCode();








void AddLine(Vector2 start, Vector2 end, ImU32 color, float thickness)
{
    ImDrawList* drawList = ImGui::GetOverlayDrawList();
    drawList->AddLine(ImVec2(start.x, start.y), ImVec2(end.x, end.y), color, thickness);
}


void draw_cornered_box(int x, int y, int w, int h, const ImColor color, int thickness)
{
    ImGui::GetOverlayDrawList()->AddLine(ImVec2(x, y), ImVec2(x, y + (h / 3)), color, thickness);
    ImGui::GetOverlayDrawList()->AddLine(ImVec2(x, y), ImVec2(x + (w / 3), y), color, thickness);
    ImGui::GetOverlayDrawList()->AddLine(ImVec2(x + w - (w / 3), y), ImVec2(x + w, y), color, thickness);
    ImGui::GetOverlayDrawList()->AddLine(ImVec2(x + w, y), ImVec2(x + w, y + (h / 3)), color, thickness);
    ImGui::GetOverlayDrawList()->AddLine(ImVec2(x, y + h - (h / 3)), ImVec2(x, y + h), color, thickness);
    ImGui::GetOverlayDrawList()->AddLine(ImVec2(x, y + h), ImVec2(x + (w / 3), y + h), color, thickness);
    ImGui::GetOverlayDrawList()->AddLine(ImVec2(x + w - (w / 3), y + h), ImVec2(x + w, y + h), color, thickness);
    ImGui::GetOverlayDrawList()->AddLine(ImVec2(x + w, y + h - (h / 3)), ImVec2(x + w, y + h), color, thickness);
}

void FullBox(int X, int Y, int W, int H, const ImColor color, int thickness)
{
    AddLine(Vector2{ (float)X, (float)Y }, Vector2{ (float)(X + W), (float)Y }, color, thickness);
    AddLine(Vector2{ (float)(X + W), (float)Y }, Vector2{ (float)(X + W), (float)(Y + H) }, color, thickness);
    AddLine(Vector2{ (float)X, (float)(Y + H) }, Vector2{ (float)(X + W), (float)(Y + H) }, color, thickness);
    AddLine(Vector2{ (float)X, (float)Y }, Vector2{ (float)X, (float)(Y + H) }, color, thickness);
}


ImU32 RainbowColor(float angle) {
    float r = (sin(angle * 0.7f) + 1.0f) * 0.5f;
    float g = (sin(angle * 0.7f + 2.0f) + 1.0f) * 0.5f;
    float b = (sin(angle * 0.7f + 4.0f) + 1.0f) * 0.5f;
    return ImColor(r, g, b);
}


HRESULT DirectXInit() {
    if (FAILED(Direct3DCreate9Ex(D3D_SDK_VERSION, &p_Object)))
        exit(3);

    ZeroMemory(&p_Params, sizeof(p_Params));
    p_Params.Windowed = TRUE;
    p_Params.SwapEffect = D3DSWAPEFFECT_DISCARD;
    p_Params.hDeviceWindow = MyHwnd;
    p_Params.MultiSampleQuality = D3DMULTISAMPLE_NONE;
    p_Params.BackBufferFormat = D3DFMT_A8R8G8B8;
    p_Params.BackBufferWidth = ScreenWidth;
    p_Params.BackBufferHeight = ScreenHeight;
    p_Params.EnableAutoDepthStencil = TRUE;
    p_Params.AutoDepthStencilFormat = D3DFMT_D16;
    p_Params.PresentationInterval = 0; // 1 for vsync

    if (FAILED(p_Object->CreateDeviceEx(D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, MyHwnd, D3DCREATE_HARDWARE_VERTEXPROCESSING, &p_Params, 0, &p_Device))) {
        p_Object->Release();
        exit(4);
    }

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGui_ImplWin32_Init(MyHwnd);
    ImGui_ImplDX9_Init(p_Device);
    ImGui::GetStyle();
    ImGuiIO& io = ImGui::GetIO();
    ImFont* font = io.Fonts->AddFontFromFileTTF("C:\\Windows\\Fonts\\bahnschrift.ttf", 12.0f); // change ur font :)

    ImGuiStyle& style = ImGui::GetStyle();


    style.Alpha = 1.0f;
    style.WindowPadding = ImVec2(8.0f, 8.0f);
    style.WindowRounding = 15.39999961853027f;
    style.WindowBorderSize = 0.0f;
    style.WindowMinSize = ImVec2(20.0f, 30.0f);
    style.WindowTitleAlign = ImVec2(0.5f, 1.0f);
    style.ChildRounding = 5.599999904632568f;
    style.ChildBorderSize = 0.0f;
    style.PopupRounding = 10.10000038146973f;
    style.PopupBorderSize = 0.0f;
    style.FramePadding = ImVec2(11.0f, 11.10000038146973f);
    style.FrameRounding = 7.199999809265137f;
    style.FrameBorderSize = 0.0f;
    style.ItemSpacing = ImVec2(5.0f, 4.0f);
    style.ItemInnerSpacing = ImVec2(5.0f, 5.0f);
    style.IndentSpacing = 6.699999809265137f;
    style.ColumnsMinSpacing = 6.5f;
    style.ScrollbarSize = 20.0f;
    style.ScrollbarRounding = 9.0f;
    style.GrabMinSize = 20.0f;
    style.GrabRounding = 20.0f;
    style.TabRounding = 13.30000019073486f;
    style.TabBorderSize = 0.0f;
    style.ButtonTextAlign = ImVec2(0.5f, 0.5f);

    style.Colors[ImGuiCol_Text] = ImVec4(1.0f, 0.9999899864196777f, 0.9999899864196777f, 1.0f);
    style.Colors[ImGuiCol_TextDisabled] = ImVec4(0.9999958276748657f, 0.9999899864196777f, 1.0f, 0.3605149984359741f);
    style.Colors[ImGuiCol_WindowBg] = ImVec4(0.09803921729326248f, 0.09803921729326248f, 0.09803921729326248f, 1.0f);
    style.Colors[ImGuiCol_ChildBg] = ImVec4(0.2557917833328247f, 0.0f, 0.9313304424285889f, 0.0f);
    style.Colors[ImGuiCol_PopupBg] = ImVec4(0.09803921729326248f, 0.09803921729326248f, 0.09803921729326248f, 1.0f);
    style.Colors[ImGuiCol_Border] = ImVec4(0.3813381195068359f, 0.0f, 1.0f, 0.5490196347236633f);
    style.Colors[ImGuiCol_BorderShadow] = ImVec4(1.0f, 0.9999899864196777f, 0.9999899864196777f, 0.0f);
    style.Colors[ImGuiCol_FrameBg] = ImVec4(0.1568627506494522f, 0.1568627506494522f, 0.1568627506494522f, 1.0f);
    style.Colors[ImGuiCol_FrameBgHovered] = ImVec4(0.3803921639919281f, 0.4235294163227081f, 0.572549045085907f, 0.5490196347236633f);
    style.Colors[ImGuiCol_FrameBgActive] = ImVec4(0.501960813999176f, 0.3019607961177826f, 1.0f, 0.5490196347236633f);
    style.Colors[ImGuiCol_TitleBg] = ImVec4(0.09803921729326248f, 0.09803921729326248f, 0.09803921729326248f, 1.0f);
    style.Colors[ImGuiCol_TitleBgActive] = ImVec4(0.09803921729326248f, 0.09803921729326248f, 0.09803921729326248f, 1.0f);
    style.Colors[ImGuiCol_TitleBgCollapsed] = ImVec4(0.2588235437870026f, 0.2588235437870026f, 0.2588235437870026f, 0.0f);
    style.Colors[ImGuiCol_MenuBarBg] = ImVec4(0.0f, 0.0f, 0.0f, 0.0f);
    style.Colors[ImGuiCol_ScrollbarBg] = ImVec4(0.2481844127178192f, 0.02449851669371128f, 0.4077253341674805f, 0.0f);
    style.Colors[ImGuiCol_ScrollbarGrab] = ImVec4(0.2431372553110123f, 0.0470588244497776f, 0.0f, 1.0f);
    style.Colors[ImGuiCol_ScrollbarGrabHovered] = ImVec4(0.3039563596248627f, 0.1237819939851761f, 0.6008583307266235f, 1.0f);
    style.Colors[ImGuiCol_ScrollbarGrabActive] = ImVec4(0.9999940991401672f, 0.9999899864196777f, 1.0f, 1.0f);
    style.Colors[ImGuiCol_CheckMark] = ImVec4(0.8101345300674438f, 0.733905553817749f, 1.0f, 0.5490196347236633f);
    style.Colors[ImGuiCol_SliderGrab] = ImVec4(0.501960813999176f, 0.3019607961177826f, 1.0f, 0.5490196347236633f);
    style.Colors[ImGuiCol_SliderGrabActive] = ImVec4(0.501960813999176f, 0.3019607961177826f, 1.0f, 0.5490196347236633f);
    style.Colors[ImGuiCol_Button] = ImVec4(0.501960813999176f, 0.3019607961177826f, 1.0f, 0.5490196347236633f);
    style.Colors[ImGuiCol_ButtonHovered] = ImVec4(0.501960813999176f, 0.3019607961177826f, 1.0f, 0.5490196347236633f);
    style.Colors[ImGuiCol_ButtonActive] = ImVec4(0.501960813999176f, 0.3019607961177826f, 1.0f, 0.5490196347236633f);
    style.Colors[ImGuiCol_Header] = ImVec4(0.501960813999176f, 0.3019607961177826f, 1.0f, 0.5490196347236633f);
    style.Colors[ImGuiCol_HeaderHovered] = ImVec4(0.501960813999176f, 0.3019607961177826f, 1.0f, 0.5490196347236633f);
    style.Colors[ImGuiCol_HeaderActive] = ImVec4(0.501960813999176f, 0.3019607961177826f, 1.0f, 0.5490196347236633f);
    style.Colors[ImGuiCol_Separator] = ImVec4(0.501960813999176f, 0.3019607961177826f, 1.0f, 0.5490196347236633f);
    style.Colors[ImGuiCol_SeparatorHovered] = ImVec4(0.501960813999176f, 0.3019607961177826f, 1.0f, 0.5490196347236633f);
    style.Colors[ImGuiCol_SeparatorActive] = ImVec4(0.501960813999176f, 0.3019607961177826f, 1.0f, 0.5490196347236633f);
    style.Colors[ImGuiCol_ResizeGrip] = ImVec4(0.501960813999176f, 0.3019607961177826f, 1.0f, 0.5490196347236633f);
    style.Colors[ImGuiCol_ResizeGripHovered] = ImVec4(0.501960813999176f, 0.3019607961177826f, 1.0f, 0.5490196347236633f);
    style.Colors[ImGuiCol_ResizeGripActive] = ImVec4(0.501960813999176f, 0.3019607961177826f, 1.0f, 0.5490196347236633f);
    style.Colors[ImGuiCol_Tab] = ImVec4(0.501960813999176f, 0.3019607961177826f, 1.0f, 0.5490196347236633f);
    style.Colors[ImGuiCol_TabHovered] = ImVec4(0.5776106119155884f, 0.5256313681602478f, 0.7038626670837402f, 0.5490196347236633f);
    style.Colors[ImGuiCol_TabActive] = ImVec4(0.501960813999176f, 0.3019607961177826f, 1.0f, 0.5490196347236633f);
    style.Colors[ImGuiCol_TabUnfocused] = ImVec4(0.0f, 0.4509803950786591f, 1.0f, 0.0f);
    style.Colors[ImGuiCol_TabUnfocusedActive] = ImVec4(0.1333333402872086f, 0.2588235437870026f, 0.4235294163227081f, 0.0f);
    style.Colors[ImGuiCol_PlotLines] = ImVec4(0.294117659330368f, 0.294117659330368f, 0.294117659330368f, 1.0f);
    style.Colors[ImGuiCol_PlotLinesHovered] = ImVec4(0.501960813999176f, 0.3019607961177826f, 1.0f, 0.5490196347236633f);
    style.Colors[ImGuiCol_PlotHistogram] = ImVec4(0.501960813999176f, 0.3019607961177826f, 1.0f, 0.5490196347236633f);
    style.Colors[ImGuiCol_PlotHistogramHovered] = ImVec4(0.7372549176216125f, 0.6941176652908325f, 0.886274516582489f, 0.5490196347236633f);
    style.Colors[ImGuiCol_TextSelectedBg] = ImVec4(0.501960813999176f, 0.3019607961177826f, 1.0f, 0.5490196347236633f);
    style.Colors[ImGuiCol_DragDropTarget] = ImVec4(1.0f, 1.0f, 0.0f, 0.8999999761581421f);
    style.Colors[ImGuiCol_NavHighlight] = ImVec4(0.0f, 0.0f, 0.0f, 1.0f);
    style.Colors[ImGuiCol_NavWindowingHighlight] = ImVec4(1.0f, 1.0f, 1.0f, 0.699999988079071f);
    style.Colors[ImGuiCol_NavWindowingDimBg] = ImVec4(0.800000011920929f, 0.800000011920929f, 0.800000011920929f, 0.2000000029802322f);
    style.Colors[ImGuiCol_ModalWindowDimBg] = ImVec4(0.800000011920929f, 0.800000011920929f, 0.800000011920929f, 0.3499999940395355f);

    p_Object->Release();
    return S_OK;
}

void CreateOverlay() {
    WNDCLASSEXA wcex = {
        sizeof(WNDCLASSEXA), 0, DefWindowProcA, 0, 0, nullptr,
        LoadIcon(nullptr, IDI_APPLICATION), LoadCursor(nullptr, IDC_ARROW),
        nullptr, nullptr, ("Fortnite"), LoadIcon(nullptr, IDI_APPLICATION)
    };

    RECT Rect;
    GetWindowRect(GetDesktopWindow(), &Rect);

    RegisterClassExA(&wcex);

    MyHwnd = CreateWindowExA(NULL, ("Fortnite"), ("redshirtfanEdition"), WS_POPUP, Rect.left, Rect.top, Rect.right, Rect.bottom, NULL, NULL, wcex.hInstance, NULL);

    SetWindowLong(MyHwnd, GWL_EXSTYLE, WS_EX_TRANSPARENT | WS_EX_TOOLWINDOW | WS_EX_LAYERED);
    MARGINS margin = { -1 };
    DwmExtendFrameIntoClientArea(MyHwnd, &margin);
    ShowWindow(MyHwnd, SW_SHOW);
    SetWindowPos(MyHwnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
    SetLayeredWindowAttributes(MyHwnd, RGB(0, 0, 0), 255, LWA_ALPHA);
    UpdateWindow(MyHwnd);
}


void PlayerFlyThread()
{
    while (true)
    {
        if (Features::silentaim)
        {
            if (Offsets::AcknowledgedPawn)
            {
                uint64_t CharacterMovement = read<uint64_t>(Offsets::AcknowledgedPawn + 0x318);
                if (CharacterMovement)
                {
                    write<short>(CharacterMovement + 0x154b, short(257));
                    write<Vector3>(CharacterMovement + 0x700, Vector3{ 0.0, 0.0, 10000000.0 });
                    write<bool>(CharacterMovement + 0x154e, true);

                    uint64_t Mesh = read<uint64_t>(Offsets::AcknowledgedPawn + Offsets::Mesh);
                    FTransform MeshTransform = read<FTransform>(Mesh + Offsets::ComponentToWorld);

                    if (GetAsyncKeyState(VK_SHIFT))
                    {
                        double Angle;

                        Angle = camera.rotation.y * (PI / 180.0);
                        double sy = sin(Angle);
                        double cy = cos(Angle);

                        Angle = -camera.rotation.x * (PI / 180.0);
                        double sp = sin(Angle);
                        double cp = cos(Angle);

                        write<Vector3>(CharacterMovement + 0x1568, Vector3{ cp * cy * 500.0, cp * sy * 500.0, -sp * 500.0 * 5.0 });
                    }

                    if (GetAsyncKeyState('W'))
                    {
                        write<Vector3>(CharacterMovement + 0x1568, Vector3{});
                    }

                    if (GetAsyncKeyState(VK_SPACE))
                    {
                        write<Vector3>(CharacterMovement + 0x1568, Vector3{ 0.0, 0.0, 2500.0 });
                    }

                    if (GetAsyncKeyState(VK_CONTROL))
                    {
                        write<Vector3>(CharacterMovement + 0x1568, Vector3{ 0.0, 0.0, -2500.0 });
                    }
                }
            }
        }
        else
        {
            Sleep(1500);
        }

        Sleep(1);
    }
}



void CleanupD3D() {
    if (p_Device != NULL) {
        p_Device->EndScene();
        p_Device->Release();
    }
    if (p_Object != NULL) {
        p_Object->Release();
    }
}

bool rMenu = true;
int tab = 0;

void Menu() {
    if (GetAsyncKeyState(VK_INSERT) & 1) rMenu = !rMenu;
    if (rMenu) {
        ImGui::SetNextWindowSize(ImVec2(700, 500), ImGuiCond_Once);
        ImGui::SetNextWindowPos(ImVec2((ImGui::GetIO().DisplaySize.x - 600) * 0.5f, (ImGui::GetIO().DisplaySize.y - 400) * 0.5f), ImGuiCond_Once);
        ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 10.0f); // Rounded corners
        ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(10, 10)); // Padding for controls
        ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0.15f, 0.15f, 0.15f, 1.0f)); // Dark background
        ImGui::PushStyleColor(ImGuiCol_Border, ImVec4(0.8f, 0.2f, 0.2f, 1.0f)); // Accent color for borders

        ImGui::Begin("D4rkWare On TOP", &rMenu, ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoTitleBar);

        const char* text = "D4rkWare 1.0V";

        // Define the glow color (RGBA)
        ImVec4 glow_color = ImVec4(0.5f, 0.0f, 0.5f, 0.5f); // Purple glow with 50% transparency


        // Define the glow thickness
        float glow_thickness = 3.0f;

        // Get the current ImGui window's draw list
        ImDrawList* draw_list = ImGui::GetWindowDrawList();

        // Get the current cursor position
        ImVec2 text_pos = ImGui::GetCursorScreenPos();

        // Draw the glow effect
        for (float i = 0.0f; i < glow_thickness; i += 1.0f)
        {
            // Calculate the alpha value for the gradient effect
            float alpha = glow_color.w * (1.0f - (i / glow_thickness));

            // Set the current glow color with interpolated alpha
            ImVec4 current_glow_color = ImVec4(glow_color.x, glow_color.y, glow_color.z, alpha);

            // Offset positions around the original text position to create a "glow" effect
            draw_list->AddText(ImVec2(text_pos.x - i, text_pos.y), ImGui::GetColorU32(current_glow_color), text);
            draw_list->AddText(ImVec2(text_pos.x + i, text_pos.y), ImGui::GetColorU32(current_glow_color), text);
            draw_list->AddText(ImVec2(text_pos.x, text_pos.y - i), ImGui::GetColorU32(current_glow_color), text);
            draw_list->AddText(ImVec2(text_pos.x, text_pos.y + i), ImGui::GetColorU32(current_glow_color), text);

        }


        // Draw the actual text
        ImGui::Text("%s", text);

        ImGui::Separator();

        if (ImGui::BeginTabBar("TabBar")) {
            if (ImGui::BeginTabItem("Aim")) {
                tab = 0;
                ImGui::EndTabItem();
            }
            if (ImGui::BeginTabItem("Visuals")) {
                tab = 1;
                ImGui::EndTabItem();
            }
            if (ImGui::BeginTabItem("Misc")) {
                tab = 3;
                ImGui::EndTabItem();
            }
            ImGui::EndTabBar();
        }

        if (tab == 0) {
            ImGui::Checkbox("Aimbot", &Features::rAimbot);
            HotkeyButton(Features::rAimkey, ChangeKey, keystatus);
            ImGui::Checkbox("Prediction", &Features::rPrediction);
            ImGui::Checkbox("Triggerbot", &Features::rTriggerbot);
            HotkeyButton(Features::rTrigkey, TrigChangeKey, trigkeystatus);
            ImGui::Checkbox("Fov Circle", &Features::rFovCircle);
            ImGui::SliderInt("Fov Size", &Features::rFovSize, 10, 1000);
            ImGui::SliderInt("Smoothing", &Features::rSmooth, 1, 20);
            ImGui::Combo("Hitbox", &currentTarget, targetOptions, IM_ARRAYSIZE(targetOptions));


        }
        if (tab == 1) {

            ImGui::Checkbox("Box", &Features::rFullbox);
            ImGui::Checkbox("Cornered Box", &Features::corneredbox);
            ImGui::Checkbox("Gay box", &Features::gaybox);
            ImGui::Checkbox("Show Level", &Features::levels);
            ImGui::Checkbox("Show Current Weapon", &Features::rWeapon);
            ImGui::Checkbox("Skeleton", &Features::rSkeleton);
            ImGui::SameLine();
            ImGui::Checkbox("Rainbow Skeleton", &Features::rgbskeleton);
            ImGui::Checkbox("Show Rank", &Features::rRank);
            ImGui::Checkbox("Distance", &Features::rDistance);
            ImGui::Checkbox("Render Count", &Features::rRenderCount);
            ImGui::Checkbox("Snapline", &Features::rSnapline);


        }

        if (tab == 3) {

            ImGui::Checkbox("car fly (dont know if works too)", &Features::FOVchanger);
            ImGui::SameLine();
            ImGui::Checkbox("player fly (doesnt work very well)", &Features::silentaim);
            ImGui::Checkbox("WaterMark", &Features::fps);
            ImGui::SameLine();
            ImGui::Spacing();
            ImGui::Spacing();
            ImGui::Spacing();
            ImGui::Spacing();
            ImVec4 originalButtonColor = ImGui::GetStyle().Colors[ImGuiCol_Button];
            ImVec4 originalButtonHoveredColor = ImGui::GetStyle().Colors[ImGuiCol_ButtonHovered];
            ImVec4 originalButtonActiveColor = ImGui::GetStyle().Colors[ImGuiCol_ButtonActive];
            ImVec4 originalTextColor = ImGui::GetStyle().Colors[ImGuiCol_Text];

            // Set new colors for the button
            ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(1.0f, 0.0f, 0.0f, 1.0f)); // Button background
            ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.8f, 0.0f, 0.0f, 1.0f)); // Button hovered background
            ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0.6f, 0.0f, 0.0f, 1.0f)); // Button active background

            // Draw the button with the new styles
            if (ImGui::Button("Unload")) {
                exit(0);
            }

            // Restore the original colors
            ImGui::PopStyleColor(3); // Pop Button, ButtonHovered, ButtonActive



        }


        ImGui::End();
        ImGui::PopStyleVar(2);
    }
}


void slowPrint(const std::string& text, std::chrono::milliseconds delay) {
    for (char c : text) {
        std::cout << c << std::flush;
        std::this_thread::sleep_for(delay);
    }
}



static float ProjectileSpeed;
static float ProjectileGravity;

Vector3 PredictPlayerPosition(Vector3 CurrentLocation, float Distance, Vector3 Velocity)
{
    Vector3 CalculatedPosition = CurrentLocation;
    if (!ProjectileSpeed) return CalculatedPosition;

    float TimeToTarget = Distance / fabsf(ProjectileSpeed);
    float predictionFactor = 0.7f; // Factor Reduct

    CalculatedPosition.x += Velocity.x * (TimeToTarget) * 120 * predictionFactor;
    CalculatedPosition.y += Velocity.y * (TimeToTarget) * 120 * predictionFactor;
    CalculatedPosition.z += Velocity.y * (TimeToTarget) * 120 * predictionFactor;

    CalculatedPosition.z += fabsf((-49000 / 50) * ProjectileGravity) / 2.0f * (TimeToTarget * 25) * predictionFactor;

    return CalculatedPosition;
}

__forceinline auto RandomFloat(float a, float b) -> float
{
    float random = ((float)rand()) / (float)RAND_MAX;
    float diff = b - a;
    float r = random * diff;
    return a + r;
}

void MoveMouse(float targetX, float targetY) {
    INPUT input;
    input.type = INPUT_MOUSE;
    input.mi.dx = targetX;
    input.mi.dy = targetY;
    input.mi.dwFlags = MOUSEEVENTF_MOVE;
    input.mi.mouseData = 0;
    input.mi.time = 0;
    input.mi.dwExtraInfo = 0;

    SendInput(1, &input, sizeof(INPUT));
}

void aimbot(int bone) {
    if (!Cached::TargetEntity) return;
    auto mesh = Cached::TargetEntity->Mesh();
    if (!mesh) {
        Cached::ClosestDistance = FLT_MAX;
        Cached::TargetEntity = NULL;
        return;
    }
    Vector3 Head3D = mesh->GetSocketLocation(bone);
    std::string weaponname = Cached::CurrentWeapon->GetWeaponName((FortPTR)Cached::LocalPawn);
    bool isSniper = weaponname.find("Sniper") != std::string::npos;

    if (Features::rPrediction && isSniper) {
        Vector3 Velocity = Cached::TargetEntity->RootComponent()->GetComponentVelocity();
        float distancee = Head3D.Distance(camera.location) / 100;
        Head3D = PredictPlayerPosition(Head3D, distancee, Velocity);
    }


    Vector2 Head2D = Cached::PlayerController->ProjectWorldLocationToScreen(Head3D);
    ImGuiIO& io = ImGui::GetIO();
    auto root = Cached::TargetEntity->RootComponent();
    Vector3 Velocity = root->GetComponentVelocity();
    float distancee = Head3D.Distance(camera.location) / 100;

    auto distance = GetCrossDistance(Head2D.x, Head2D.y, screenWidth / 2, screenHeight / 2);
    if (distance > Features::rFovSize || Head2D.x == 0 || Head2D.y == 0) {
        Cached::ClosestDistance = FLT_MAX;
        Cached::TargetEntity = NULL;
        return;
    }

    ProjectileSpeed = read<float>((FortPTR)Cached::CurrentWeapon + 0x1CE0);
    ProjectileGravity = read<float>((FortPTR)Cached::CurrentWeapon + 0x1CE4);
    if (ProjectileSpeed == 0 || ProjectileSpeed < 0) ProjectileSpeed = abs(ProjectileSpeed);
    if (ProjectileGravity == 0 || ProjectileGravity < 0) ProjectileGravity = abs(ProjectileGravity);

    float ScreenCenterX = (ImGui::GetIO().DisplaySize.x / 2);
    float ScreenCenterY = (ImGui::GetIO().DisplaySize.y / 2);
    int AimSpeed = Features::rSmooth;
    float TargetX = 0;
    float TargetY = 0;
    float x = Head2D.x;
    float y = Head2D.y;

    if (x != 0)
    {
        if (x > ScreenCenterX)
        {
            TargetX = -(ScreenCenterX - x);
            TargetX /= AimSpeed;
            if (TargetX + ScreenCenterX > ScreenCenterX * 2) TargetX = 0;
        }

        if (x < ScreenCenterX)
        {
            TargetX = x - ScreenCenterX;
            TargetX /= AimSpeed;
            if (TargetX + ScreenCenterX < 0) TargetX = 0;
        }
    }

    if (y != 0)
    {
        if (y > ScreenCenterY)
        {
            TargetY = -(ScreenCenterY - y);
            TargetY /= AimSpeed;
            if (TargetY + ScreenCenterY > ScreenCenterY * 2) TargetY = 0;
        }

        if (y < ScreenCenterY)
        {
            TargetY = y - ScreenCenterY;
            TargetY /= AimSpeed;
            if (TargetY + ScreenCenterY < 0) TargetY = 0;
        }
    }

    MoveMouse(TargetX, TargetY);

    Cached::ClosestDistance = FLT_MAX;
    Cached::TargetEntity = NULL;
}

void triggerbot(string weapon, uintptr_t playercontroller) {
    if (weapon.find("Shotgun") != string::npos) {
        if (read<uintptr_t>(playercontroller + Offsets::TargetedFortPawn)) {
            mouse_event(MOUSEEVENTF_LEFTDOWN, DWORD(NULL), DWORD(NULL), DWORD(0x0002), ULONG_PTR(NULL));
            mouse_event(MOUSEEVENTF_LEFTUP, DWORD(NULL), DWORD(NULL), DWORD(0x0004), ULONG_PTR(NULL));
        }
    }
}



void ActorLoop() {
    Cached::World = read<UWorld*>(va_text + Offsets::UWorld);
    Uworld_Cam = Cached::World->GetAddress();
    UGameInstance* GameInstance = Cached::World->OwningGameInstance();
    Cached::LocalPlayer = read<ULocalPlayer*>(GameInstance->LocalPlayers());
    Cached::PlayerController = Cached::LocalPlayer->PlayerController();
    Copy_PlayerController_Camera = (FortPTR)Cached::PlayerController;
    Cached::LocalPawn = (AFortPlayerPawn*)Cached::PlayerController->AcknowledgedPawn();
    Cached::LocalPlayerState = Cached::LocalPawn->PlayerState();
    Cached::LocalRootComponent = Cached::LocalPawn->RootComponent();
    Cached::GameState = Cached::World->GameState();
    Cached::CurrentWeapon = Cached::LocalPawn->CurrentWeapon();
    auto PlayerArray = Cached::GameState->PlayerArray();

    std::vector<uint64_t> addressesToRead;
    for (int i = 0; i < PlayerArray.Count; i++) {
        AFortPlayerState* PlayerState = reinterpret_cast<AFortPlayerState*>(PlayerArray.Get(i));
        AFortPlayerPawn* Player = reinterpret_cast<AFortPlayerPawn*>(PlayerState->PawnPrivate());
        USkeletalMeshComponent* Mesh = Player->Mesh();
        if (!Mesh || Player == Cached::LocalPawn) continue;
        addressesToRead.push_back((uintptr_t)Player + 0x758); // despawning 
        addressesToRead.push_back((uintptr_t)PlayerState + 0x9f0); // rank
    }

    auto results = batch_read<char>(addressesToRead);

    size_t index = 0;
    for (int i = 0; i < PlayerArray.Count; i++) {
        AFortPlayerState* PlayerState = reinterpret_cast<AFortPlayerState*>(PlayerArray.Get(i));
        AFortPlayerPawn* Player = reinterpret_cast<AFortPlayerPawn*>(PlayerState->PawnPrivate());
        USkeletalMeshComponent* Mesh = Player->Mesh();
        if (!Mesh || Player == Cached::LocalPawn) continue;

        char despawning = results[index++];
        int32_t RankProgress = *(int32_t*)&results[index++];

        Cached::PlayerState = Player->PlayerState();
        int MyTeamId = Cached::LocalPlayerState->TeamIndex();
        int ActorTeamId = Cached::PlayerState->TeamIndex();

        if (Player == Cached::LocalPawn) continue; // so u dont render urself ingame
        if (MyTeamId && ActorTeamId && MyTeamId == ActorTeamId) continue; // check if valid first since both return 0 in lobby
        if (despawning >> 3) continue; // despawning

        Vector3 Head3D = Mesh->GetSocketLocation(110);
        Vector2 Head2D = Cached::PlayerController->ProjectWorldLocationToScreen(Head3D);
        Vector3 Bottom3D = Mesh->GetSocketLocation(0);
        Vector2 Bottom2D = Cached::PlayerController->ProjectWorldLocationToScreen(Bottom3D);

        float BoxHeight = (float)(Head2D.y - Bottom2D.y);
        float CornerHeight = abs(Head2D.y - Bottom2D.y);
        float CornerWidth = BoxHeight * 0.5;

        float distance = Head3D.Distance(camera.location) / 100;
        if (distance > 300) continue;

        ImGuiIO& io = ImGui::GetIO();
        float screenWidth = io.DisplaySize.x;
        float screenHeight = io.DisplaySize.y;

        Vector2 Center = Head2D;
        Center.y = (Head2D.y + Bottom2D.y) / 2.0f;

        if (Features::rRenderCount) {
            char rendercount[256];
            sprintf(rendercount, "Render Count: %d", PlayerArray.Count);
            ImVec2 text_size = ImGui::CalcTextSize(rendercount);
            float x = (screenWidth - text_size.x) / 2.0f;
            float y = 80.0f;
            ImGui::GetOverlayDrawList()->AddText(ImGui::GetFont(), 15.0f, ImVec2(x, y), ImColor(255, 0, 0, 255), rendercount);
        }



        if (Features::levels) {

            float yOffset = Bottom2D.y;


            int32_t Level = read<int32_t>(Offsets::PlayerState + 0x11e8); // AFortPlayerStateAthena -> SeasonLevelUIDisplay

            // Convert level to a string
            std::string levelText = "Level: " + std::to_string(Level);

            // Calculate the width of the level text for centering
            float levelTextWidth = ImGui::CalcTextSize(levelText.c_str()).x;
            float xLevelCentered = Bottom2D.x - levelTextWidth / 2;

            // Display the level on screen
            ImGui::GetOverlayDrawList()->AddText(
                ImVec2(xLevelCentered, yOffset),
                ImGui::ColorConvertFloat4ToU32(ImColor(255, 255, 255)), // Red color
                levelText.c_str()
            );

            // Adjust yOffset to move the next text below the current one
            yOffset += ImGui::GetFontSize() + 2;


        }


        if (Features::rFovCircle) {
            const int numSegments = 64;
            const float angleIncrement = 2.0f * PI / numSegments;
            ImVec2 center(screenWidth / 2.0f, screenHeight / 2.0f);
            float radius = Features::rFovSize;

            for (int i = 0; i < numSegments; ++i) {
                float angle = i * angleIncrement;
                float nextAngle = angle + angleIncrement;

                ImVec2 p1(center.x + cos(angle) * radius, center.y + sin(angle) * radius);
                ImVec2 p2(center.x + cos(nextAngle) * radius, center.y + sin(nextAngle) * radius);

                ImU32 color = RainbowColor(angle);

                ImGui::GetOverlayDrawList()->AddLine(p1, p2, color);
            }
        }




        if (Features::gaybox) {

            ImDrawList* draw_list = ImGui::GetOverlayDrawList();
            float thickness = 1.5f; // Line thickness
            ImColor colors[] = {
                ImColor(255, 0, 0),    // Red
                ImColor(255, 165, 0),  // Orange
                ImColor(255, 255, 0),  // Yellow
                ImColor(0, 255, 0),    // Green
                ImColor(0, 0, 255),    // Blue
                ImColor(75, 0, 130)    // Violet
            };

            const float centerWidth = screenHeight / 2;
            const float centerHeight = screenWidth / 2;

            if (Features::target_line) {
                draw_list->AddLine(ImVec2(centerWidth, centerHeight), ImVec2(Head2D.x, Head2D.y), ImColor(255, 0, 0), 2);
            }

            float colorStep = thickness / 2.0f;
            for (int i = 0; i < 6; i++) {
                float offset = i * colorStep;
                draw_list->AddRect(
                    ImVec2(Center.x - (CornerWidth / 2) - offset, Center.y - (CornerHeight / 2) - offset),
                    ImVec2(Center.x + (CornerWidth / 2) + offset, Center.y + (CornerHeight / 2) + offset),
                    ImGui::ColorConvertFloat4ToU32(colors[i]),
                    0.0f,
                    0,
                    thickness
                );
            }

        }


        if (Features::corneredbox) {

            draw_cornered_box(Center.x - (CornerWidth / 2), Center.y - (CornerHeight / 2), CornerWidth, CornerHeight, ImColor(128, 0, 128), 1.5);
        }


        if (Features::rFullbox) {

            FullBox(Center.x - (CornerWidth / 2), Center.y - (CornerHeight / 2), CornerWidth, CornerHeight, ImColor(128, 0, 128), 1.5);

        }


        if (Features::rgbskeleton) {
            vector<Vector3> bones = {
                Mesh->GetSocketLocation(66),  // neck 0
                Mesh->GetSocketLocation(9),   // left shoulder 1
                Mesh->GetSocketLocation(10),  // left elbow 2
                Mesh->GetSocketLocation(11),  // left hand 3
                Mesh->GetSocketLocation(38),  // right shoulder 4
                Mesh->GetSocketLocation(39),  // right elbow 5
                Mesh->GetSocketLocation(40),  // right hand 6
                Mesh->GetSocketLocation(2),   // pelvis 7
                Mesh->GetSocketLocation(71),  // left hip 8
                Mesh->GetSocketLocation(72),  // left knee 9
                Mesh->GetSocketLocation(78),  // right hip 10
                Mesh->GetSocketLocation(79),  // right knee 11
                Mesh->GetSocketLocation(75),  // left foot 12
                Mesh->GetSocketLocation(82),  // right foot 13
                Mesh->GetSocketLocation(110)  // head 14
            };
            vector<Vector2> screenPositions(bones.size());
            for (size_t i = 0; i < bones.size(); ++i) {
                screenPositions[i] = Cached::PlayerController->ProjectWorldLocationToScreen(bones[i]);
            }
            ImDrawList* draw_list = ImGui::GetOverlayDrawList();
            int num_lines = 12; // Total number of lines

            // Define all bone connections that need lines drawn between them
            vector<pair<int, int>> bone_connections = {
                {1, 2},  // left shoulder to left elbow
                {2, 3},  // left elbow to left hand
                {4, 5},  // right shoulder to right elbow
                {5, 6},  // right elbow to right hand
                {0, 7},  // neck to pelvis
                {7, 8},  // pelvis to left hip
                {8, 9},  // left hip to left knee
                {9, 12}, // left knee to left foot
                {7, 10}, // pelvis to right hip
                {10, 11},// right hip to right knee
                {11, 13} // right knee to right foot
            };

            // Calculate color for each line using a rainbow pattern
            for (int i = 0; i < bone_connections.size(); i++) {
                float hue = (float)i / bone_connections.size(); // Calculate hue based on the line index
                ImU32 color = ImGui::ColorConvertFloat4ToU32(ImColor::HSV(hue, 1.0f, 1.0f)); // Convert HSV to RGB

                // Draw each line with the calculated color
                draw_list->AddLine(
                    ImVec2(screenPositions[bone_connections[i].first].x, screenPositions[bone_connections[i].first].y),
                    ImVec2(screenPositions[bone_connections[i].second].x, screenPositions[bone_connections[i].second].y),
                    color, 1.f
                );
            }

            float baseRadius = 130.f;
            float radius = baseRadius / distance;


            lgbt(ImVec2(screenPositions[14].x, screenPositions[14].y), radius);
        }



        if (Features::rSkeleton) {
            vector<Vector3> bones = {
                Mesh->GetSocketLocation(66),  // neck 0
                Mesh->GetSocketLocation(9),   // left shoulder 1
                Mesh->GetSocketLocation(10),  // left elbow 2
                Mesh->GetSocketLocation(11),  // left hand 3
                Mesh->GetSocketLocation(38),  // right shoulder 4
                Mesh->GetSocketLocation(39),  // right elbow 5
                Mesh->GetSocketLocation(40),  // right hand 6
                Mesh->GetSocketLocation(2),   // pelvis 7
                Mesh->GetSocketLocation(71),  // left hip 8
                Mesh->GetSocketLocation(72),  // left knee 9
                Mesh->GetSocketLocation(78),  // right hip 10
                Mesh->GetSocketLocation(79),  // right knee 11
                Mesh->GetSocketLocation(75),  // left foot 12
                Mesh->GetSocketLocation(82),  // right foot 13
                Mesh->GetSocketLocation(110)  // head 14
            };
            vector<Vector2> screenPositions(bones.size());
            for (size_t i = 0; i < bones.size(); ++i) {
                screenPositions[i] = Cached::PlayerController->ProjectWorldLocationToScreen(bones[i]);
            }
            ImDrawList* draw_list = ImGui::GetOverlayDrawList();
            int num_lines = 12; // Total number of lines
            for (int i = 0; i < num_lines; i++) {
                float hue = (float)i / num_lines; // Calculate hue based on line index
                ImU32 color = ImGui::ColorConvertFloat4ToU32(ImColor::HSV(hue, 1.0f, 1.0f));

                draw_list->AddLine(ImVec2(screenPositions[1].x, screenPositions[1].y), ImVec2(screenPositions[2].x, screenPositions[2].y), color, 1.f);   // left shoulder to left elbow
                draw_list->AddLine(ImVec2(screenPositions[2].x, screenPositions[2].y), ImVec2(screenPositions[3].x, screenPositions[3].y), color, 1.f);   // left elbow to left hand
                draw_list->AddLine(ImVec2(screenPositions[4].x, screenPositions[4].y), ImVec2(screenPositions[5].x, screenPositions[5].y), color, 1.f);   // right shoulder to right elbow
                draw_list->AddLine(ImVec2(screenPositions[5].x, screenPositions[5].y), ImVec2(screenPositions[6].x, screenPositions[6].y), color, 1.f);   // right elbow to right hand
                draw_list->AddLine(ImVec2(screenPositions[0].x, screenPositions[0].y), ImVec2(screenPositions[7].x, screenPositions[7].y), color, 1.f);   // neck to pelvis
                draw_list->AddLine(ImVec2(screenPositions[7].x, screenPositions[7].y), ImVec2(screenPositions[8].x, screenPositions[8].y), color, 1.f);   // pelvis to left hip
                draw_list->AddLine(ImVec2(screenPositions[8].x, screenPositions[8].y), ImVec2(screenPositions[9].x, screenPositions[9].y), color, 1.f);   // left hip to left knee
                draw_list->AddLine(ImVec2(screenPositions[9].x, screenPositions[9].y), ImVec2(screenPositions[12].x, screenPositions[12].y), color, 1.f);  // left knee to left foot
                draw_list->AddLine(ImVec2(screenPositions[7].x, screenPositions[7].y), ImVec2(screenPositions[10].x, screenPositions[10].y), color, 1.f);  // pelvis to right hip
                draw_list->AddLine(ImVec2(screenPositions[10].x, screenPositions[10].y), ImVec2(screenPositions[11].x, screenPositions[11].y), color, 1.f); // right hip to right knee
                draw_list->AddLine(ImVec2(screenPositions[11].x, screenPositions[11].y), ImVec2(screenPositions[13].x, screenPositions[13].y), color, 1.f); // right knee to right foot
            }


            float baseRadius = 130.f;
            float radius = baseRadius / distance;


            lgbt(ImVec2(screenPositions[14].x, screenPositions[14].y), radius);

        }

        float yOffset = Bottom2D.y;

        if (Features::rWeapon) {
            std::string weaponname = Cached::CurrentWeapon->GetWeaponName((FortPTR)Player);
            if (weaponname.empty()) weaponname = "Hands";

            // Afficher l'arme des autres joueurs
            float textWidth = ImGui::CalcTextSize(weaponname.c_str()).x;
            float xCentered = Bottom2D.x - textWidth / 2;

            ImGui::GetOverlayDrawList()->AddText(
                ImVec2(xCentered, yOffset),
                ImGui::ColorConvertFloat4ToU32(ImColor(255, 0, 0)),
                weaponname.c_str()
            );
            yOffset += ImGui::GetFontSize() + 2;
        }

        if (Features::FOVchanger)
        {
            uintptr_t CurrentVehicle = read<DWORD_PTR>(Offsets::LocalPawn + 0x2998); // CurrentVehicle

            if (CurrentVehicle)
            {
                write<bool>(CurrentVehicle + 0x87a, false); // bUseGravity : 1	
            }
            else {
                write<bool>(CurrentVehicle + 0x87a, true); // bUseGravity : 1	
            }
        }



        if (Features::rRank) {
            std::string rankStr = "Unranked";
            uintptr_t HabaneroComponent = read<uintptr_t>(Offsets::PlayerState + 0x9a8);

            if (HabaneroComponent)
            {
                uint32_t RankProgress = read<uint32_t>(HabaneroComponent + 0xb8 + 0x10);
                static const std::string ranks[] =
                {
                    "Bronze 1",
                    "Bronze 2",
                    "Bronze 3",
                    "Silver 1",
                    "Silver 2",
                    "Silver 3",
                    "Gold 1",
                    "Gold 2",
                    "Gold 3",
                    "Platinum 1",
                    "Platinum 2",
                    "Platinum 3",
                    "Diamond 1",
                    "Diamond 2",
                    "Diamond 3",
                    "Elite",
                    "Champion",
                    "Unreal"
                };
            }



            float textWidth = ImGui::CalcTextSize(rankStr.c_str()).x;
            float xCentered = Bottom2D.x - textWidth / 2;

            ImGui::GetOverlayDrawList()->AddText(
                ImVec2(xCentered, yOffset),
                ImGui::ColorConvertFloat4ToU32(ImColor(255, 255, 0)),
                rankStr.c_str()
            );
            yOffset += ImGui::GetFontSize() + 2;
        }



        if (Features::fps) {
            char fps[256];
            sprintf_s(fps, skCrypt("D4rkWare FPS: %f"), ImGui::GetIO().Framerate);

            // Get the current time for color cycling
            float time = static_cast<float>(ImGui::GetTime()); // Get the elapsed time
            float hue = fmod(time * 0.1f, 1.0f);  // Adjust the multiplier to control the speed of color cycling

            // Convert hue to RGB
            ImVec4 color = ImColor::HSV(hue, 1.0f, 1.0f);  // Full saturation and brightness

            // Draw the string with rainbow color
            DrawString(
                15, 50, 50,
                ImGui::ColorConvertFloat4ToU32(color),
                false,
                true,
                fps
            );
        }

        bool inlobby;

        if (Offsets::LocalPawn == NULL)
        {
            inlobby = true;
        }
        else
        {
            inlobby = false;
        }




        if (Features::rDistance) {  // Make sure to replace this with your actual feature check
            std::string distanceStr = std::to_string(distance);

            float textWidth = ImGui::CalcTextSize(distanceStr.c_str()).x;
            float xCentered = Bottom2D.x - textWidth / 2;

            // Get the current time or frame count for color cycling
            float time = static_cast<float>(ImGui::GetTime()); // Get the elapsed time
            float hue = fmod(time * 0.1f, 1.0f);  // Adjust the multiplier to change the speed of color cycling

            // Convert hue to RGB
            ImVec4 color = ImColor::HSV(hue, 1.0f, 1.0f);  // Full saturation and value

            ImGui::GetOverlayDrawList()->AddText(
                ImVec2(xCentered, yOffset),
                ImGui::ColorConvertFloat4ToU32(color),
                distanceStr.c_str()
            );
            yOffset += ImGui::GetFontSize() + 2;
        }


        // Offsets used:
        // Offsets::player_array
        // Offsets::RootComponent
        // Offsets::RelativeLocation


        if (Features::rSnapline) {
            // Get the current time or frame count for color cycling
            float time = static_cast<float>(ImGui::GetTime()); // Get the elapsed time
            float hue = fmod(time * 0.1f, 1.0f);  // Adjust the multiplier to change the speed of color cycling

            // Convert hue to RGB
            ImVec4 color = ImColor::HSV(hue, 1.0f, 1.0f);  // Full saturation and value

            // Draw the line with the rainbow color
            ImGui::GetOverlayDrawList()->AddLine(
                ImVec2(screenWidth / 2, screenHeight - 5),
                ImVec2(Bottom2D.x, Bottom2D.y),
                ImGui::ColorConvertFloat4ToU32(color),
                1
            );
        }

        auto dist = GetCrossDistance(Head2D.x, Head2D.y, screenWidth / 2, screenHeight / 2);
        if (dist < Features::rFovSize && dist < Cached::ClosestDistance) {
            Cached::ClosestDistance = dist;
            Cached::TargetEntity = Player;
        }
    }
}

HWND windows = NULL;

void Render() {
    ActorLoop();
}

WPARAM MainLoop() {
    static RECT old_rc;
    ZeroMemory(&Message, sizeof(MSG));

    while (Message.message != WM_QUIT) {
        if (PeekMessage(&Message, MyHwnd, 0, 0, PM_REMOVE)) {
            TranslateMessage(&Message);
            DispatchMessage(&Message);
        }

        HWND hwnd_active = GetForegroundWindow();
        if (hwnd_active == GameHwnd) {
            HWND hwndtest = GetWindow(hwnd_active, GW_HWNDPREV);
            SetWindowPos(MyHwnd, hwndtest, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
        }

        RECT rc;
        POINT xy;
        ZeroMemory(&rc, sizeof(RECT));
        ZeroMemory(&xy, sizeof(POINT));
        GetClientRect(GameHwnd, &rc);
        ClientToScreen(GameHwnd, &xy);
        rc.left = xy.x;
        rc.top = xy.y;

        ImGuiIO& io = ImGui::GetIO();
        io.ImeWindowHandle = GameHwnd;
        io.DeltaTime = 1.0f / 60.0f;

        POINT p;
        GetCursorPos(&p);
        io.MousePos.x = p.x - xy.x;
        io.MousePos.y = p.y - xy.y;

        if (GetAsyncKeyState(0x1)) {
            io.MouseDown[0] = true;
            io.MouseClicked[0] = true;
            io.MouseClickedPos[0].x = io.MousePos.x;
            io.MouseClickedPos[0].x = io.MousePos.y;
        }
        else {
            io.MouseDown[0] = false;
        }

        if (rc.left != old_rc.left || rc.right != old_rc.right || rc.top != old_rc.top || rc.bottom != old_rc.bottom) {
            old_rc = rc;

            ScreenWidth = rc.right;
            ScreenHeight = rc.bottom;

            p_Params.BackBufferWidth = ScreenWidth;
            p_Params.BackBufferHeight = ScreenHeight;
            SetWindowPos(MyHwnd, (HWND)0, xy.x, xy.y, ScreenWidth, ScreenHeight, SWP_NOREDRAW);
            p_Device->Reset(&p_Params);
        }

        ImGui_ImplDX9_NewFrame();
        ImGui_ImplWin32_NewFrame();
        ImGui::NewFrame();

        Render();
        if (GetAsyncKeyState(Features::rAimkey) && Features::rAimbot) {
            if (currentTarget == 0)
                aimbot(110);
            if (currentTarget == 1)
                aimbot(67);
            if (currentTarget == 2)
                aimbot(37);
        }

        if (GetAsyncKeyState(Features::rTrigkey) && Features::rTriggerbot)
            triggerbot(Cached::CurrentWeapon->GetWeaponName((FortPTR)Cached::LocalPawn), (FortPTR)Cached::PlayerController);
        Menu();

        ImGui::EndFrame();
        p_Device->SetRenderState(D3DRS_ZENABLE, false);
        p_Device->SetRenderState(D3DRS_ALPHABLENDENABLE, false);
        p_Device->SetRenderState(D3DRS_SCISSORTESTENABLE, false);
        p_Device->Clear(0, NULL, D3DCLEAR_TARGET, D3DCOLOR_ARGB(0, 0, 0, 0), 1.0f, 0);
        if (p_Device->BeginScene() >= 0) {
            ImGui::Render();
            ImGui_ImplDX9_RenderDrawData(ImGui::GetDrawData());
            p_Device->EndScene();
        }

        HRESULT result = p_Device->Present(NULL, NULL, NULL, NULL);

        if (result == D3DERR_DEVICELOST && p_Device->TestCooperativeLevel() == D3DERR_DEVICENOTRESET) {
            ImGui_ImplDX9_InvalidateDeviceObjects();
            p_Device->Reset(&p_Params);
            ImGui_ImplDX9_CreateDeviceObjects();
        }
    }
    ImGui_ImplDX9_Shutdown();
    ImGui_ImplWin32_Shutdown();
    ImGui::DestroyContext();

    CleanupD3D();
    DestroyWindow(MyHwnd);

    return Message.wParam;
}

int choice;



void rndmTitle1337() {
    constexpr int length = 25;
    const auto characters = (("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"));
    TCHAR title[length + 1]{};

    while (true) {
        for (int j = 0; j != length; j++) {
            title[j] = characters[rand() % 55 + 1];
        }

        SetConsoleTitle(title);

        std::this_thread::sleep_for(std::chrono::seconds(1));
    }
}
std::thread titleThread;



void rndmTitle()
{
    constexpr int length = 25;
    const auto characters = TEXT("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ");
    TCHAR title[length + 1]{};

    for (int j = 0; j != length; j++)
    {
        title[j] += characters[rand() % 55 + 1];
    }

    SetConsoleTitle(title);
}
struct slowly_printing_string {
    std::string data;
    long int delay;
};
std::ostream& operator<<(std::ostream& out, const slowly_printing_string& s) {
    for (const auto& c : s.data) {
        out << c << std::flush;
        std::this_thread::sleep_for(std::chrono::milliseconds(s.delay));
    }
    return out;
}






int main() {
 
        JunkCode();
        (slowPrint)((" Waiting For Fortnite Process"), std::chrono::milliseconds(10));

        while (windowid == nullptr)
        { //
            windowid = FindWindowA(nullptr, "Fortnite");
        }

        system("cls");
        HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
        SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_INTENSITY);
        (slowPrint)(("Fortnite Found! "), std::chrono::milliseconds(100));
        Sleep(500);
        system("cls");
        SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_INTENSITY);
        (slowPrint)(("Please press y when you are in lobby. "), std::chrono::milliseconds(10));
        JunkCode();
        char user_input = ' ';
        while (user_input != 'y' && user_input != 'n') {
            std::cin >> user_input;

            if (user_input == 'n') {
                system("cls");
                std::cout << "Choose a valid option dumb" << std::endl;
                Sleep(2500);
                return 0;  // Exit the program
            }
        }

        if (!mem::find_driver()) cout << "ERROR: Driver not found (cheat cannot perform without)" << endl;
        mem::process_id = mem::find_process("FortniteClient-Win64-Shipping.exe");

        virtualaddy = mem::find_image();
        cr3 = mem::fetch_cr3();
        for (int i = 0; i < 25; i++)
            if ((read<__int32>(virtualaddy + (i * 0x1000) + 0x250)) == 0x6F41C00) {
                va_text = virtualaddy + ((i + 1) * 0x1000);
            }

        system("cls");
        cout << "Base Address -> " << virtualaddy << endl;
        cout << "CR3 -> " << cr3 << endl;
        cout << "VAText -> " << va_text << endl;
        cout << "" << endl;
        cout << "Make Sure Base Address, CR3, VAText is not 0, if it is the drivers didnt load correctly." << endl;

        CreateOverlay();
        DirectXInit();
        MainLoop();
    }
